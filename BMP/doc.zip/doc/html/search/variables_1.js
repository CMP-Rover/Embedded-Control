var searchData=
[
  ['b1_60',['b1',['../structbmp180__calib__data.html#a754eab24857aa57ee314c2fde889ff95',1,'bmp180_calib_data']]],
  ['b2_61',['b2',['../structbmp180__calib__data.html#a5da53749cc3349c6f5da29f4433a58b7',1,'bmp180_calib_data']]]
];
