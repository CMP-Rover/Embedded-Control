var indexSectionsWithContent =
{
  0: "_abgmps",
  1: "_b",
  2: "b",
  3: "bgps",
  4: "abm",
  5: "b",
  6: "b",
  7: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

