var searchData=
[
  ['getpressure_50',['getPressure',['../class___b_m_p180__.html#acedef27e84e4d5e8acf48e7505cc215c',1,'_BMP180_']]],
  ['gettemperature_51',['getTemperature',['../class___b_m_p180__.html#a0253d2038c9d868b66df11926e4cd25f',1,'_BMP180_']]]
];
